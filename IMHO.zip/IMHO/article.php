  <div class="row">
 
  <div class="col-sm-8">
  <h3><strong>FEATURED ARTICLES</strong></h3>
    <div class="col-sm-6">
	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/1.png" alt="1" />    
	<p style="font-family:'Courier New', Courier, monospace">03/August/2016  <span style="color:#CCCCCC;">Length: 5,772 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>Marxist-Humanism's Contribution to Developing Perspectives for Transcending Capitalism</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
          Except of a speech to the IMHO Convention in Chicago, July 2-3, 2016. It addresses, with particular attention to
          Latin America and to Marx's Critique of the Gotha program<a href="#">[...]</a></p>
      <hr> 
     <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/>  By:PETER HUDIS
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>
<!--end 1-->
	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/3.png" alt="3" />    
	<p style="font-family:'Courier New', Courier, monospace">26/July/2016  <span style="color:#CCCCCC;">Length: 728 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>Coup and Counter-cop in Turkey</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
         Since the failure of a military coup against him on night of 5 july 2016, Turkey's president Erdogan has launched a coup of his own, camping down hard on all opposition<a href="#">[...]</a></p>
      <hr> 
     <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/>  By: RICHARD ABERNETHY
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>

<!--end 3-->

	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/5.png" alt="5" />    
	<p style="font-family:'Courier New', Courier, monospace">17/July/2016  <span style="color:#CCCCCC;">Length: 4,782 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>On the Perils of Populism:Brexit,the Left and the EU</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
    This article is based on a presentation for the 2016 convention of the international Marxist-Humanist organization on philosophic 
    perspectives on Anti-Capitalism<a href="#">[...]</a></p>
      <hr> 
     <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/>  By: DEVID BLACK
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>

<!--end 5-->
    </div>
 
 
  
	
    <div class="col-sm-6">
        	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/2.png" alt="2" />    
	<p style="font-family:'Courier New', Courier, monospace">02/August/2016  <span style="color:#CCCCCC;">Length: 8,679 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>Political Crises in Africa and the Globalization of Racism</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
    The economic and political crisis in africa today especially in Angola, Gambia, Ivory Coast, Nigeria, and South Africa is connected to ruthless
    exploitation by Euro-US and Middle Eastern<a href="#">[...]</a></p>
      <hr> 
      <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/><span>  By: BA KARANG</span>
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>

<!--end 2-->

	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/4.png" alt="4" />    
	<p style="font-family:'Courier New', Courier, monospace">26/July/2016  <span style="color:#CCCCCC;">Length: 561 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>Morocco: Mohammed VI: 17 years and Counting</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
     Escalating political repression in Morocco under the rule of King Mohammed VI makes this a crucial moment to solidarize with human rights
     activists and freedom fighters being targeted<a href="#">[...]</a></p>
      <hr> 
     <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/>  By: MAATI MONJIB
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>

<!--end 4-->

	<img class="img-thumbnail img-responsive" src="<?php echo get_template_directory_uri()?>/img/6.png" alt="6" />    
	<p style="font-family:'Courier New', Courier, monospace">07/July/2016  <span style="color:#CCCCCC;">Length: 6,318 words</span></p>
	<h3 style="font-family:'Times New Roman', Times, serif"><strong>Dialectical Tensions: Marcuse, Dunayevskaya and the Problems of the Age</strong></h3>
      
      <p style="font-family:'Times New Roman', Times, serif">
      This article explores Raya Dunayevskaya and Herbert Marcuse's humanism and dialectics, arguing in favour of the former's open and negative conception of dialectical possibilities<a href="#">[...]</a></p>
      <hr> 
     <img style=" height: 30px; width: 30px; float: left; margin-right: 10px;" class="img-responsive img-circle" src="<?php echo get_template_directory_uri()?>/img/rasel.jpg" alt="me"/>  By: DAMIN GERBER & SHANNON BRINCAT
      <span class="glyphicon glyphicon-arrow-right btn-md" style="float: right"></span>
<hr>
<!--end 6-->
    </div>
	</div>
      
      <div class="col-sm-4"><br>
            <h4 style=""><strong>ABOUT IMHO</strong></h4>
      <p>This article explores Raya Dunayevskaya and Herbert Marcuse's humanism and dialectics, arguing in favour of the former's open and negative conception of dialectical possibilities
      This article explores Raya Dunayevskaya and Herbert Marcuse's humanism and dialectics, arguing in favour of the former's open and negative conception of dialectical possibilities</p>
      
      
      <p><button type="button" class="btn-default btn-md" value="">Read More</button></p>
      <hr>
      
       <h4 style=""><strong>KEEP IN TOUCH WITH IMHO</strong></h4>
      <p>This article explores Raya Dunayevskaya and Herbert Marcuse's humanism and dialectics, arguing in favour of the former's open and negative conception of dialectical possibilities
      This article explores Raya Dunayevskaya and Herbert Marcuse's humanism and dialectics,
      </p>
      
      
      <p><button type="button" class="btn-default btn-md" value="">SIGN UP</button></p>
      <HR>
      <div class="row">
     
      <h4 style=""><strong>UPCOMING EVENTS</strong></h4>
    <div class="col-sm-2">
               <img src="<?php echo get_template_directory_uri()?>/img/minus.png" alt="minus" style="height:40px; width:40px" class=" img-responsive img-circle"/>
          </div>
               <div class="col-sm-10">
   <p style="font-weight: bold">   Loss Angels - women of color as Revolutionary Force and Reason, Form marx to Today
    </p>
    <h6>
        Date: September 25,2016<br>
        Time: 6 - 8:30 p.m.<br>
        Address: West side Peace  Center<br>
        3916 Sepulveda Blvd,Suite 101-102.<br><br>
        <a href="#" class="btn btn-default" style="text-decoration: none">View More</a>
    </h6>   <hr>
               </div>
         </div>
      
      <div class="row">
      <div class="col-sm-2">
               <img src="<?php echo get_template_directory_uri()?>/img/plus.png" alt="plus" style="height:40px; width:40px" class=" img-responsive img-circle"/>
          </div>
          <div class="col-sm-10">
              <p style="font-weight: bold">   Loss Angels - Crisis in Middle East and Europe: From Turkey to France and Beyond
              </p>   
             
    <hr><hr style="margin-top: -17px">
    
          </div>
          
          </div>
      
       <h2 style="font-family:'Courier New', Courier, monospace; font-weight: bold">ANNOUNCEMENTS</h2> 
         
      <div class="row">
          
      <div class="col-sm-4">
               <img src="<?php echo get_template_directory_uri()?>/img/announce.png" alt="announce" style="" class=" img-responsive "/>
          </div>
          <div class="col-sm-8">
              <h6> September 11,2012  </h6>
              <h4 style="font-weight: bold"> 
              Arabic Translation of Raya Dunaevskaya's arxism and Freedom
              </h4>   
             
  
    
          </div>
          
          </div>
       <hr>
       
       <div class="row">
          
      <div class="col-sm-4">
               <img src="<?php echo get_template_directory_uri()?>/img/the_spanish.png" alt="the_spanish" style="" class=" img-responsive "/>
          </div>
          <div class="col-sm-8">
              <h6> March 25,2012  </h6>
              <h4 style="font-weight: bold"> 
              The Spanish Translation of Raya Dunayevskaya's The Power of Negativity
              </h4>   
             
  
    
          </div>
          
          </div>
       
      </div>
	 </div>