 <center>
        <p style="color: #C7C7C7;">(c) 2017 The International Marxist-Humanist</p>
        <p style="color: #C7C7C7;">Design & Developed by <a href="http://rasel.wpsi29.com"><i>RASEL AHSAN</i></a></p>
    </center>