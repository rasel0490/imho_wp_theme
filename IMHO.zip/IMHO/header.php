<head>
      <title><?php wp_title('|',true,'left');?>Rasel Ahsan</title>
    <meta charset="utf-8">
	  <meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="Content-Script-Type" content="text/javascript">
<meta name="Content-Style-Type" content="text/css">

  <link rel="stylesheet" href="<?php echo get_template_directory_uri()?>/css/bootstrap.min.css">
  <script src="<?php echo get_template_directory_uri()?>/js/jquery.min.js"></script>
  <script src="<?php echo get_template_directory_uri()?>/js/bootstrap.min.js"></script>
  </head>