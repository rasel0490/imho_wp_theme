<?php get_header();?>

<body>
 <div style=" background-color: #A5391F; padding:80px; width: auto 100%" class="  container-fluid text-center"><!--background-image:url(img/BANNER1.PNG); width: 100%; height: 400px;-->
  <P style="font-size:18px; color:white;">The International Marxist-Humanist</P>
  <p style="font-size:26px; color:white; font-weight:bold;">FOR A HUMANIST ALTERNATIVE<BR> TO CAPITALISM</p>
</div>

<!--strart navbar-->
<div class="container" >
<div class="row">
<div class="col-sm-1"></div>
<div class="col-sm-10">


<nav class="navbar navbar-inverse" style="background-color:#FFFFFF; color:#000000; border:hidden; font-weight:bold; padding:0px 0px 0px 0px">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="#">HOME</a></li>
        <li><a href="#">ABOUT</a></li>
        <li><a href="#">ARTICALS</a></li>
        <li><a href="#">LITERATURE</a></li>
		  <li><a href="#">AUDIO/VIDEO</a></li>
        <li><a href="#">LANGUAGE+</a></li>
        <li><a href="#">EVENTS</a></li>
        <li><a href="#">CONTACT</a></li>
		 <li><a href="#"> <span class="glyphicon glyphicon-search"></span></a></li>
      </ul>
      <?php wp_nav_menu(array('theme_location'=>'primary','menu_class'=>'nav navbar-nav'));?>
    </div>
  </div>
</nav>
<hr>
</div>
<div class="col-sm-1"></div>
</div>
</div>

<!--end navbar-->

<!-- start Feature article-->
<div class="container">
<?php get_template_part('article');?>
</div> 
<center ><a href="#" style="font-weight: bold; padding: 50px; text-decoration: none" class="glyphicon glyphicon-refresh">  LOAD MORE ARTICLE</a></center>
<!-- end Feature article-->

<!-- start recent publication-->

<div class="container-fluid" style="background-color: #FFB246; padding: 20PX;" id="recent_publication">
    <center><h3 style="font-family:'Courier New', Courier, monospace; font-weight: bold; padding: 10PX;">RECENT PUBLICATIONS of INTEREST</h3></center>
   <?php get_template_part('recent_publication');?>
</div>

<div class="container-fluid" style="background-color: #BB3720">
    <center><h4 style="margin: 15px 0px 15px 0px; padding: 5px; color:#FFFFFF; font-weight: bold; ">Check our archive for full list of our publications <a href="#" class="btn btn-default">BOOK ARCHIVE</a></h4></center>
</div>
<!-- end recent publication-->

<!--start raya-->
<div id="raya" class="container-fluid" style="padding: 30px">
    <center>
        <img src="<?php echo get_template_directory_uri()?>/img/raya.png" alt="raya" class="img-responsive img-thumbnail"/>
        <h3 style="font-family:'Times New Roman', Times, serif; font-weight:bold;">
            WRITING OF RAYA DUNAYEVSKAYA
        </h3>
        <h5 style="font-family:'Times New Roman', Times, serif; color: #ADADAD;">
            and other Marxist-Humanist Classics
        </h5>
    </center>
   
</div>
 <?php get_template_part('raya');?>
<!--end raya-->

<!--start footer-->
<div id="footer" class="container-fluid" style="background-color: #262626; padding: 10px">
   <?php get_template_part('footer');?>
   
</div>
<!--end footer-->
</body>
