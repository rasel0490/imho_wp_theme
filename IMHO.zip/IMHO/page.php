<?php get_header();?>
<body>
 <div style=" background-color: #A5391F; padding:80px; width: auto 100%" class="  container-fluid text-center"><!--background-image:url(img/BANNER1.PNG); width: 100%; height: 400px;-->
  <P style="font-size:18px; color:white;">The International Marxist-Humanist</P>
  <p style="font-size:26px; color:white; font-weight:bold;">FOR A HUMANIST ALTERNATIVE<BR> TO CAPITALISM</p>
</div>

<!--strart navbar-->
<div class="container" >
<div class="row">
<div class="col-sm-1"></div>
<div class="col-sm-10">


<nav class="navbar navbar-inverse" style="background-color:#FFFFFF; color:#000000; border:hidden; font-weight:bold; padding:0px 0px 0px 0px">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="#">HOME</a></li>
        <li><a href="#">ABOUT</a></li>
        <li><a href="#">ARTICALS</a></li>
        <li><a href="#">LITERATURE</a></li>
		  <li><a href="#">AUDIO/VIDEO</a></li>
        <li><a href="#">LANGUAGE+</a></li>
        <li><a href="#">EVENTS</a></li>
        <li><a href="#">CONTACT</a></li>
		 <li><a href="#"> <span class="glyphicon glyphicon-search"></span></a></li>
      </ul>
      <?php wp_nav_menu(array('theme_location'=>'primary','menu_class'=>'nav navbar-nav'));?>
    </div>
  </div>
</nav>
<hr>
</div>
<div class="col-sm-1"></div>
</div>
</div>

<!--end navbar-->
<div class="main-content">
 <div class="row" style="background-color:#f4f5f7;margin-left:-15px">
 <div class="col-sm-1"></div>
    <div class="col-sm-8" style="margin-left:">
      <?php get_template_part('post-loop');?>
	</div><br><br><br>
    <div class="col-sm-3 side-bar" style="background-color:#dae3f2;"> 
	<aside id="secondary" role="complementary"><br>
		<section id="search-3" class="widget widget_search"><form role="search" method="get" class="search-form" action="#">
				<label>
					<span class="screen-reader-text"></span>
					<input class="search-field" placeholder="Search " value="" name="s" type="search">
				</label>
				<input class="search-submit" value="Search" type="submit">
			</form></section>
		<section class="widget">
		
<?php wp_nav_menu(array('theme_location'=>'primary1','menu_class'=>'nav nav-pills nav-stacked nav-pills-stacked-example'));?>
		</section>
		
		
	</aside>
    </div>
 </div>
 
</div>

<!--start footer-->
<div id="footer" class="container-fluid" style="background-color: #262626; padding: 10px">
   <?php get_template_part('footer');?>
   
</div>
<!--end footer-->
</body>