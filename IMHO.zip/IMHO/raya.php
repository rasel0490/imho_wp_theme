 <div class="row" style="padding: 20px">
    <div class="col-sm-2"></div>
    <div style="background-color: #FBF7F1; margin-right: 20px; padding: 20px; font-family:'Times New Roman', Times, serif;" class="col-sm-4">
         <H4><strong>Draft Thesis: The Turing Point</strong></H4>
         <h5  style="padding: 20px">The assessment of Goldwater in this draft thesis is referenced in the recent International 
             Marxist-Humanist Organization article, Theoretical and practical perspectives for Overcoming Capitalism.</h5>
         <p><a href="#" style="text-decoration: none; font-weight: bold;">Download PDF Fle</a></p>
    </div>
    
    <div style="background-color: #FBF7F1; padding: 15px; margin-right: 20px; font-family:'Times New Roman', Times, serif;" class="col-sm-4">
               <H4><strong>The R. Dunayevskaya Collection is Now Online.</strong></H4>
               <h5  style="padding: 20px">The assessment of Goldwater in this draft thesis is referenced in the recent International 
             Marxist-Humanist Organization article, Theoretical and practical perspectives for Overcoming Capitalism.
              The assessment of Goldwater in this draft thesis is referenced in the recent International 
             Marxist-Humanist 
               
               </h5>
                <p><a href="#" style="text-decoration: none; font-weight: bold;">Read More</a></p>
    
        
    </div>
    <div class="col-sm-2"></div>
    </div>