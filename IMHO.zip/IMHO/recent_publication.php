 <div class="row" >
    <div class="col-sm-2"> </div>
    <div class="col-sm-2">
             <img class="img-responsive img-rounded" src="<?php echo get_template_directory_uri()?>/img/interest1.png" alt="1"/>
             <h4 style="font-family:'Courier New', Courier, monospace; font-weight: bold">
                 Democracy, Dialectics, and Difference
             </h4>
              <h5>By: Brian C.Lovato</h5>
    </div>
    <div class="col-sm-2">
         <img class="img-responsive img-rounded" src="<?php echo get_template_directory_uri()?>/img/interest2.png" alt="2"/>
           <h4 style="font-family:'Courier New', Courier, monospace; font-weight: bold">
                 Marx at the Margins
             </h4>
              <h5>By: Kevin B.Anderson</h5>
    </div>
    <div class="col-sm-2">
         <img class="img-responsive img-rounded" src="<?php echo get_template_directory_uri()?>/img/interest3.png" alt="3"/>
          <h4 style="font-family:'Courier New', Courier, monospace; font-weight: bold">
                 The Philosophical Roots of Anti-Capitalism
             </h4>
              <h5>By: David Black</h5>     
    </div>
    <div class="col-sm-2">
         <img class="img-responsive img-rounded" src="<?php echo get_template_directory_uri()?>/img/interest4.png" alt="4"/>
             <h4 style="font-family:'Courier New', Courier, monospace; font-weight: bold">
                 marx's Concept of the Alternative to Capitalism
             </h4>
              <h5>By: Peter Hudis</h5>
    </div>
       <div class="col-sm-2"></div>
</div>